import sys,os
from pymqa import *
from pymqacore import *
from scipy.stats import linregress

def main():
 srcdir = "C:\\Users\\shuancai\\Desktop\\MQA_test\\Python_Test\\IV_Sweeps\\QA_nmos\\QA_model\\2_detail\\04_Mathematic_Robustness_1\\Rule_5001\\Check_01"
 prjs = loadmqaresult( srcdir )
 if len(prjs) == 0 :
  print( "No MQA result is found under given directory!")
  return
 outputdir = "postresult"
 if not os.path.isdir( outputdir ):
  os.mkdir( outputdir )
 #clean previous plots
 cleandir( outputdir )

 os.chdir( outputdir )
 pb = PlotBuilder()     #object to create plots or tables
 prj1 = prjs[0]
 #showinfo( prj1, "prj1_info.txt" )

 #-- rule: "Check Ids vs. Vgs"
 Ids = prj1.searchtag( "Ids" ,ruleid="5001" )
 pb.buildplot( Ids, "Vgs", "Vbs" )
 pb.save( )


# entry of scripts
if __name__ == "__main__" :
 main()

# -----------------------------------------------------------------------
# Running scripts file in console window:
#  <$MQAHOME/bin/>mpython this_py_file
# Demo cases:
#  $MQAHOME/example/postprocess/cases
# Document:
#  Help-> User Guide-> Applications-> Application Notes-> Post Process
# -----------------------------------------------------------------------

